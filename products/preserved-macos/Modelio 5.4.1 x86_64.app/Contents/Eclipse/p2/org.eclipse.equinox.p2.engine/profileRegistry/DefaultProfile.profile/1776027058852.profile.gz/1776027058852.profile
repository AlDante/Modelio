<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1776027058852'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/Users/david/IdeaProjects/Modelio/products/target/products/org.modelio.product/macosx/cocoa/x86_64/Modelio 5.4.1.app/Contents/Eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=macosx,osgi.arch=x86_64,osgi.ws=cocoa,osgi.nl=en_DE'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/Users/david/IdeaProjects/Modelio/products/target/products/org.modelio.product/macosx/cocoa/x86_64/Modelio 5.4.1.app/Contents/Eclipse'/>
  </properties>
</profile>
